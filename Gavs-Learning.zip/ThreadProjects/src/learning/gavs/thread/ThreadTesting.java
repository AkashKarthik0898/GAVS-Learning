package learning.gavs.thread;

public class ThreadTesting extends Thread {
	public ThreadTesting() {
		super();
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("Hi");
	}

	public static void main(String args[]) throws InterruptedException {
		ThreadTesting t = new ThreadTesting();
		Runnable rt = new Runnable() {
			@Override
			public void run() {
				System.out.println("This is a running interupt thread");
			}
		};
		Runnable r = new Runnable() {
			int i = 0;

			@Override
			public void run() {
				// TODO Auto-generated method stub
				while (i < 100) {
					System.out.println("Hello  " + i);
					i++;
				}
			}
		};

		Thread rthread = new Thread(rt);
//		t.start();
		t.run();
		r.run();
		System.out.println("The thread is waiting ");
//		rthread.start();
		rthread.run();
		System.out.println("All Threads are executed");

	}
}