package learning.gavs.thread;

public class JavaThread {

	public static void main(String args[]) {
		
	}
}
