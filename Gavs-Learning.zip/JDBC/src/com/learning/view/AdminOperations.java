package com.learning.view;

import java.sql.SQLException;
import java.util.Scanner;

import com.learning.controller.AdminUtilities;

public class AdminOperations {

	private static int choice;
	private static final AdminUtilities adutil = new AdminUtilities();
	private static final Scanner adminScanner = new Scanner(System.in);
		
	public static void startOperation() throws SQLException{
		// TODO Auto-generated method stub
		while(true) {
			System.out.println("Enter your operation:");
			System.out.print("1-Insert a data 2-Read all data from Database 3-Update data 4-Delete 5-Search for a value 6-Exit the system ");
			choice = Integer.parseInt(adminScanner.nextLine());
			
			switch(choice) {
			case 1:
				adutil.write();
				break;
			case 2:
				adutil.read();
				break;
			case 3:
				adutil.update();
				break;
			case 4:
				adutil.delete();
				break;
			case 5:
				adutil.search();
				break;
			case 6:
				adminScanner.close();
				System.exit(0);
				break;
			default:
				System.out.println("Invalid Responce. Try again");
				break;
			}
		
		}
		
	}

}
