package com.learning.view;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.learning.model.Conections;

public class Login {

	private static Connection con = null;
	private static String uname;
	private static PreparedStatement ps;
	private static String upassword;
	private static ResultSet rs;
	public static void main(String[] args) throws SQLException, IOException {
		// TODO Auto-generated method stub

		@SuppressWarnings("resource")
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter your Login UserId and Password:");
		while (true) {
			uname = scan.nextLine();
			upassword = scan.nextLine();
			con = Conections.getConnection();
			ps = con.prepareStatement("select * from user_login where uname = ? and upassword = ?");
			ps.setString(1, uname);
			ps.setString(2, upassword);
			rs = ps.executeQuery();

			if (!rs.next()) {
				System.out.println("Invalid Request. Try Again");
			} else {
				ps = con.prepareStatement("select * from user_login where uname = ?");
				ps.setString(1, uname);
				rs = ps.executeQuery();
				rs.next();
				String s = rs.getString(4);

				if (s.equalsIgnoreCase("admin")) {
					System.out.println("Welcome "+rs.getString(4)+" user! You have logged in as " + rs.getString(2)  );
					AdminOperations.startOperation();
				}
					
				else {
					System.out.println("Welcome "+rs.getString(4)+" user! You have logged in as " + rs.getString(2)  );
					UserOperations.start();
				}
					

			}
		}
	}

}
