package com.learning.view;

import java.sql.SQLException;
import java.util.Scanner;

import com.learning.controller.AdminUtilities;

public class UserOperations {

	private static int choice;
	private static final AdminUtilities userUtil = new AdminUtilities();
	private static final Scanner userScanner = new Scanner(System.in);

	public static void start() throws SQLException {
		// TODO Auto-generated method stub\

		while (true) {
			System.out.println("Enter your operation:");
			System.out.print("1-Read all data from Database 2-Search for a value 3-Exit the system ");
			choice = Integer.parseInt(userScanner.nextLine());
			switch (choice) {
			case 1:
				userUtil.read();
				break;
			case 2:
				userUtil.search();
				break;
			case 3:
				userScanner.close();
				System.exit(0);
				break;
			default:
				System.out.println("Invalid Option. Try again");
				break;

			}

		}

	}
}
