package com.learning.controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.learning.model.Conections;

public class UserUtilities extends Conections{

	PreparedStatement ps;
	static Scanner scan;
	final static Connection con;
	static {
		con = Conections.getConnection();
		scan = new Scanner(System.in);

	}
	public void read() throws SQLException {
		// TODO Auto-generated method stub

		ResultSet rs;
		Statement st = con.createStatement();
		rs = st.executeQuery("select * from user_login");
		System.out.println("\n");
		while (rs.next())
			System.out.println("Name: " + rs.getString(2) + " \tId:" + rs.getString(1) + " \tUType:" + rs.getString(4));
		System.out.println("\n");
	}
	
	public void search() throws SQLException {
		// TODO Auto-generated method stub
		int choice;
		ResultSet rs;
		PreparedStatement ps;
		System.out.println("Enter the known field:1-Uid\t2-Name\t3-Type");
		choice = Integer.parseInt(scan.nextLine());
		if (choice == 1) {
			ps = con.prepareStatement("select * from user_login where uid = ?");
			System.out.println("Enter the uid: ");
			ps.setString(1, scan.nextLine());
			rs = ps.executeQuery();
			while (rs.next())
				System.out.println("ID:" + rs.getString(1) + "\tName:" + rs.getString(2) + "\tType " + rs.getString(4));

		} else if (choice == 2) {
			ps = con.prepareStatement("select * from user_login where uname = ?");
			System.out.println("Enter the Name: ");
			ps.setString(1, scan.nextLine());
			rs = ps.executeQuery();
			while (rs.next())
				System.out.println("ID:" + rs.getString(1) + "\tName:" + rs.getString(2) + "\tType " + rs.getString(4));


		} else if (choice == 3) {
			ps = con.prepareStatement("select * from user_login where utype = ?");
			System.out.println("Enter the user type: ");
			ps.setString(1, scan.nextLine());
			rs = ps.executeQuery();
			while (rs.next())
				System.out.println("ID:" + rs.getString(1) + "\tName:" + rs.getString(2) + "\tType " + rs.getString(4));


		} else
			System.out.println("Invalid Choice");

	}

}
