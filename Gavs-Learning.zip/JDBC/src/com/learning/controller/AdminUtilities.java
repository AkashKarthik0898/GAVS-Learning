package com.learning.controller;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.learning.model.Conections;
import com.learning.model.Privilages;

public class AdminUtilities extends Conections{

	PreparedStatement ps;
	static Scanner scan;
	final static Connection con ;
	static {
		con = Conections.getConnection();
		scan = new Scanner(System.in);

	}

	public void write() throws SQLException {
		// TODO Auto-generated method stub
		int i;
		ps = con.prepareStatement("insert into user_login(uname,upassword,utype) values" + "(?,?,?)");
		System.out.println("Enter The User name , password  to add to the database:");
		ps.setString(1, scan.nextLine());
		ps.setString(2, scan.nextLine());
		System.out.println("Enter Privilage to add to the user");
		System.out.println("List of available privilages: \n 1-" + Privilages.ADMIN + "\n2-" + Privilages.MANAGER
				+ "\n3-" + Privilages.DEVELOPER + "\n4-" + Privilages.CLIENT);
		i = Integer.parseInt(scan.nextLine());
		switch (i) {
		case 1:
			ps.setString(3, Privilages.ADMIN.toString());
			ps.execute();
			System.out.println("Insert Success");
			break;
		case 2:
			ps.setString(3, Privilages.MANAGER.toString());
			ps.execute();
			System.out.println("Insert Success");
			break;
		case 3:
			ps.setString(3, Privilages.DEVELOPER.toString());
			ps.execute();
			System.out.println("Insert Success");
			break;
		case 4:
			ps.setString(3, Privilages.CLIENT.toString());
			ps.execute();
			System.out.println("Insert Success");
			break;
		default:
			System.out.println("You have selected an invalid privilage.");
		}
	}

	public void read() throws SQLException {
		// TODO Auto-generated method stub

		ResultSet rs;
		Statement st = con.createStatement();
		rs = st.executeQuery("select * from user_login");
		System.out.println("\n");
		while (rs.next())
			System.out.println("Name: " + rs.getString(2) + " \tId:" + rs.getString(1) + " \tUType:" + rs.getString(4));
		System.out.println("\n");
	}

	public void update() throws SQLException {
		// TODO Auto-generated method stub
		PreparedStatement ps;
		String uid, data, field;
		read();
		System.out.println("Enter the Uid of the person to update");
		uid = scan.nextLine();
		System.out.println("Enter the column to update:(uname/utype)");
		field = scan.nextLine();
		System.out.println("Enter the new value:");
		data = scan.nextLine();
		ps = con.prepareStatement("update user_login set " + field + " = ? where uid = " + uid);
		ps.setString(1, data);
		try {
			ps.executeUpdate();
			System.out.println("Query Executed Successfully");
		} catch (Exception e) {
			System.out.println("Invalid Input detected. Please try again");

		}

	}

	public void delete() throws SQLException {
		// TODO Auto-generated method stub
		PreparedStatement ps;
		read();
		ps = con.prepareStatement("delete from user_login where uid = ?");
		System.out.println("Select the id of the entry to delete");
		ps.setString(1, scan.nextLine());
		ps.executeUpdate();
		System.out.println("Data Deleted Successfully");
	}

	public void search() throws SQLException {
		// TODO Auto-generated method stub
		int choice;
		ResultSet rs;
		PreparedStatement ps;
		System.out.println("Enter the known field:1-Uid\t2-Name\t3-Type");
		choice = Integer.parseInt(scan.nextLine());
		if (choice == 1) {
			ps = con.prepareStatement("select * from user_login where uid = ?");
			System.out.println("Enter the uid: ");
			ps.setString(1, scan.nextLine());
			rs = ps.executeQuery();
			while (rs.next())
				System.out.println("ID:" + rs.getString(1) + "\tName:" + rs.getString(2) + "\tType " + rs.getString(4));

		} else if (choice == 2) {
			ps = con.prepareStatement("select * from user_login where uname = ?");
			System.out.println("Enter the Name: ");
			ps.setString(1, scan.nextLine());
			rs = ps.executeQuery();
			while (rs.next())
				System.out.println("ID:" + rs.getString(1) + "\tName:" + rs.getString(2) + "\tType " + rs.getString(4));

		} else if (choice == 3) {
			ps = con.prepareStatement("select * from user_login where utype = ?");
			System.out.println("Enter the user type: ");
			ps.setString(1, scan.nextLine());
			rs = ps.executeQuery();
			while (rs.next())
				System.out.println("ID:" + rs.getString(1) + "\tName:" + rs.getString(2) + "\tType " + rs.getString(4));

		} else
			System.out.println("Invalid Choice");

	}

}
