package com.learning.model;

public enum Privilages {

	ADMIN,DEVELOPER,MANAGER,CLIENT;

}
