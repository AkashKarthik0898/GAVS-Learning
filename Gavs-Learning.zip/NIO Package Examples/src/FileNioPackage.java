import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;
public class FileNioPackage {
	public static void main(String args[]) throws IOException {
//		Scanner scan = new Scanner(System.in);
		List<String> list = new ArrayList<>();
		File file = new File("Filetest.txt");
		if (!file.exists())
			try {
				file.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		Path path = Paths.get("Filetest.txt");

		list.add("Hello");
		list.add("This");
		list.add("is");
		list.add("a");
		list.add("test");
		list.add("list");
		list.add("to");
		list.add("check");
		list.add("data");
		list.add("written");
		list.add("in");
		list.add("the");
		list.add("file");
		list.add("using");
		list.add("nio");
		list.add("package");
		fileWrite(path, list);
		fileView(file,path);
//		scan.close();
		
		System.out.println("Reading File \n______________________________________________________");
		fileRead(path);
		
	}

	private static void fileView(File file, Path path) throws IOException {
		// TODO Auto-generated method stub
		if (file.length() == 0)
			System.out.println("There are no contacts to display");
		else {
			List<String> list = Files.readAllLines(path);
			list.forEach(System.out::println); // Higher Order Function
			System.out.println();
		}
	}

	private static void fileWrite(Path path, List<String> list) throws IOException {
//		Files.write(path, list, Charset.defaultCharset());
		Files.write(path, list, StandardOpenOption.APPEND);
	}
	 
	private static void fileRead(Path path) throws IOException
	{
		/*Method to get the data as a List*/
		List<String> list = Files.readAllLines(path);
		for(String s : list)
			System.out.println(s);
		
		/*Method to get the data as a String*/
		
		String fileString = Files.readString(path);
		System.out.println(fileString);
		
	}
	
	
}
