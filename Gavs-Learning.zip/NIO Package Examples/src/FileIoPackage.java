import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class FileIoPackage {

	public static void main(String args[]) throws IOException
	{
		Scanner scan = new Scanner(System.in);
		String writeString;
		File file = new File("Filetest.txt");
		if(!file.exists())
			try {
				file.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		System.out.println("Enter the lines to add to a file");
		writeString = scan.nextLine();
		fileWrite(file,writeString);
		scan.close();
	}
	
	private static void fileWrite(File file,String s) throws IOException
	{
		FileWriter fw = new FileWriter(file,true);
		fw.append(s);
//		fw.flush();
		fw.close();
		
	}
	
}
