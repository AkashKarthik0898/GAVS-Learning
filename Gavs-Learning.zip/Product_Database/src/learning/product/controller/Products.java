package learning.product.controller;

import java.util.ArrayList;

import learning.product.model.Product;
import learning.product.operations.Operations;
import learning.product.operations.AdminUtilities;
import learning.product.operations.CustomerUtilities;

class Products {

	public static CustomerUtilities p = new CustomerUtilities(new ArrayList<Product>());
	public static AdminUtilities a = new AdminUtilities(new ArrayList<Product>());

	public static void main(String[] args) {

		Operations.adminOperations(a.m_vProds, a);
		Operations.customerOperations(p.m_vProds, p);

	}
}