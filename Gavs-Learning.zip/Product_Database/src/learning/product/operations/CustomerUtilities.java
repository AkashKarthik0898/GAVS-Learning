package learning.product.operations;

import java.util.ArrayList;
import java.util.List;

import learning.product.interfaces.CustomerInterface;
import learning.product.model.Product;

public class CustomerUtilities implements CustomerInterface {

	public List<Product> m_vProds;

	public CustomerUtilities(ArrayList<Product> arrayList) {
		m_vProds = arrayList;
	}

	

	public String FindProductName(int targetID) {
		int i;
		String s = "";
		i = m_vProds.indexOf(new Product(targetID, ""));
		if (i >= 0)
			s = ((Product) m_vProds.get(i)).GetName();
		return s;
	}

	public void PrintProducts() {
		Product p;
		for (int i = 0; i < m_vProds.size(); i++) {
			p = (Product) m_vProds.get(i);
			p.PrintValues();
		}
	}
}
