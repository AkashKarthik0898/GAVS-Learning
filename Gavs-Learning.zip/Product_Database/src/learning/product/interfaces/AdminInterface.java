package learning.product.interfaces;

public interface AdminInterface {
	public void AddProduct(int newID, String newName);
	public void DeleteProduct(int targetID);
	
}
