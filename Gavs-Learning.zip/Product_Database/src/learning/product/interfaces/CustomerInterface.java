package learning.product.interfaces;

public interface CustomerInterface {
	public String FindProductName(int targetID);
	public void PrintProducts();
}
