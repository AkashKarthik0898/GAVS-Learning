package model;

public class Employee {

	private String empName , empPassword , empMail, empCountry;

	public Employee(String name , String pass, String mail , String country)
	{
		this.empName = name;
		this.empPassword = pass;
		this.empMail = mail;
		this.empCountry = country;
	}
	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getEmpPassword() {
		return empPassword;
	}

	public void setEmpPassword(String empPassword) {
		this.empPassword = empPassword;
	}

	public String getEmpMail() {
		return empMail;
	}

	public void setEmpMail(String empMail) {
		this.empMail = empMail;
	}

	public String getEmpCountry() {
		return empCountry;
	}

	public void setEmpCountry(String empCountry) {
		this.empCountry = empCountry;
	}
	
}
