package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;

import dao.DAO;
import model.Employee;


@WebServlet("/MyServlet")
public class MyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("application/json");
		PrintWriter pw = response.getWriter();
		Connection con = DAO.getConnection();
		List<Employee> empAl = new ArrayList<>();
		Gson gson= new Gson();
		try {
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("select * from emp");
			while(rs.next()) {
				Employee e = new Employee(rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5));
				empAl.add(e);
				
			}
			JsonElement element = gson.toJsonTree(empAl);
			JsonArray jsonArray = element.getAsJsonArray();
			String listData = jsonArray.toString();
					pw.write(listData);
		}catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
		}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
