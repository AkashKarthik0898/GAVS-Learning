var MyRouteApp=angular.module("mainApp",['ngRoute']);
MyRouteApp.config(function($routeProvider)
{
     $routeProvider.when('/home',
    {
        templateUrl:'home.html',
        controller:'viewController'
    })
    $routeProvider.when('/viewDetails',
    {
        templateUrl:'viewDetails.html',
        controller:'viewController'
    })
    .otherwise({
        redirectTo:'/home'
    })
});
MyRouteApp.controller('viewController',function($scope,$http){
	$http({
		method:"Get" ,
		url:"http://localhost:8080/AngularExDBMS/MyServlet"
		
	}).then(function myData(response){
		$scope.myResult = response.data
		$scope.statuscode = response.status;
	},function myError(response){
		$scope.myResult = response.data
	});
	$scope.message = "Click to view Employees"
})