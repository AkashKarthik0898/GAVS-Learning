package com.customexception;

@SuppressWarnings("serial")
public class WeightOutOfBoundException extends Exception{
	public WeightOutOfBoundException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}

}


