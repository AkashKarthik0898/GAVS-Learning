package com.bookings.operations;

import java.util.Date;
import java.util.Scanner;

import com.bookings.flights.DomesticFlight;
import com.bookings.flights.InternationalFlight;

public class Operations {

	public static int newDomesticTravel() {
		Scanner tscan = new Scanner(System.in);
		String name,idProof,natureOfTravel;
		System.out.println("Enter your name:");
		name = tscan.nextLine();
		System.out.println("Enter your Id Proof:");
		idProof = tscan.nextLine();
		System.out.print("Enter your Nature of Travel:");
		natureOfTravel = tscan.nextLine();
		DomesticFlight df = new DomesticFlight(name,idProof,natureOfTravel,new Date());
		System.out.println("Booking Details: \n" + df.toString());
		tscan.close();
		return 1;
	}

	public static int newInternationalTravel() {
		Scanner tscan = new Scanner(System.in);
		String name,idProof,natureOfTravel,PassportNumber;
		System.out.println("Enter your name:");
		name = tscan.nextLine();
		System.out.println("Enter your Id Proof:");
		idProof = tscan.nextLine();
		System.out.print("Enter your Nature of Travel:");
		natureOfTravel = tscan.nextLine();
		System.out.println("Enter Passport number");
		PassportNumber = tscan.nextLine();
		InternationalFlight inf = new InternationalFlight(name, idProof, natureOfTravel, new Date(),PassportNumber);
		System.out.println("The Booking Details is" + inf.toString());
		tscan.close();
		return 1;
	
	}

}
