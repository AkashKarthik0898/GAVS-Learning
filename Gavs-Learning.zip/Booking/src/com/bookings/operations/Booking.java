package com.bookings.operations;

import java.util.Scanner;

public class Booking {

	public static void main(String args[]) {
		int mode;
		String ch;
		Scanner intScan = new Scanner(System.in);
		Scanner chScan = new Scanner(System.in);
		do {
			System.out.println("Choose you Mode of Travel 1. Domestic \t2. International\t3.Exit");
			mode = intScan.nextInt();
			switch(mode) {
			case 1: Operations.newDomesticTravel();
			break;
			case 2: Operations.newInternationalTravel();
			break;
			case 3: intScan.close();
				chScan.close();
				System.out.println("Program has been terminated by the user");
				System.exit(0);break;
			default: System.out.println("Invalid Response."); break;
			} 
			System.out.println("Do you want to do another Transaction? (y/n)");
			ch = chScan.nextLine();
	}while(ch.charAt(0) == 'y' || ch.charAt(0) =='Y');
		

}}
