package com.bookings.flights;

import java.util.Date;

public class InternationalFlight extends Flight{
	String passportNumber,natureOfVisit;
	@Override
	public String toString() {
		return "InternationalFlight [passportNumber=" + passportNumber + ", natureOfVisit=" + natureOfVisit
				+ ", dateOfTravel=" + dateOfTravel + ", clientName=" + clientName + ", idProof=" + idProof + "]";
	}
	Date dateOfTravel;
	public InternationalFlight(String name, String idProof, String natureOfTravel, Date date,String passport) {
		dateOfTravel = date;
		natureOfVisit = natureOfTravel;
		passportNumber = passport;
		super.clientName = name;
		super.idProof = idProof;
	}
}
