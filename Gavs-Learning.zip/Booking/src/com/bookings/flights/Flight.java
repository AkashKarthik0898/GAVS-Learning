package com.bookings.flights;

public class Flight {
	String clientName;
	String idProof;
	public String getClientNamel() {
		return clientName;
	}
	public void setClientNamel(String clientNamel) {
		this.clientName = clientNamel;
	}
	public String getIdProof() {
		return idProof;
	}
	public void setIdProof(String idProof) {
		this.idProof = idProof;
	}

}
