package com.bookings.flights;

import java.util.Date;

public class DomesticFlight extends Flight {


	Date dateOfTravel;
	String natureOfVisit;
	public DomesticFlight(String name, String idProof, String natureOfTravel, Date date) {
		dateOfTravel = date;
		natureOfVisit = natureOfTravel;
		super.clientName = name;
		super.idProof = idProof;
	}
	@Override
	public String toString() {
		return "DomesticFlight [dateOfTravel=" + dateOfTravel + ", natureOfVisit=" + natureOfVisit + ", clientName="
				+ clientName + ", idProof=" + idProof + "]";
	}
	
	
}
