package learning.gavsltp.sept22;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
public class CollectionTest {


	public static void main(String args[]) {
		List<Object> list = new ArrayList<>();
		list.add("Hello");
		list.add("Welcome");
		list.add("to");
		list.add("my");
		list.add("session");
		list.add("number");
		list.add(25);			//Integer wont work in String list
		System.out.println(list);
		for(Object o : list)
			System.out.println(o);
		list.forEach(new Consumer<Object>() {

			@Override
			public void accept(Object t) {
				// TODO Auto-generated method stub
				System.out.println(t);
				
			}
		});
		list.forEach(t -> System.out.println());
		list.forEach(System.out::println);

	}
}
