package learning.gavsltp.sept20;

import java.util.ArrayList;
import java.util.List;

public class Boxing_Test {

	public static void main(String[] args) throws InterruptedException {

		System.out.println("This is from the main Function");
		int x =10;
		@SuppressWarnings("deprecation")
		Integer y = new Integer(22);
		List<Integer> list = new ArrayList<>();
		list.add(15);
		list.add(x);
		list.add(y);
		

		System.out.println(list);
		
		
	}

	public void printTest()
	{
		
		System.out.println("This is from the print function");
		int x =10;
		@SuppressWarnings("deprecation")
		Integer y = new Integer(22);
		List<Integer> list = new ArrayList<>();
		list.add(15);
		list.add(x);
		list.add(y);
		

		System.out.println(list);
		
	}
}
