package learning.gavsltp.sept21;


public class GetSetTest {

	public static void main(String arg[]) {

		GetterSetter g = new GetterSetter();
		g.setName("Akash");
		g.setId(12);
		g.setCgpa(9.9);
		System.out.println(g.toString());
		
	}
}
