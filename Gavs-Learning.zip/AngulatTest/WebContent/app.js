var MyRouteApp=angular.module("mainApp",['ngRoute']);
MyRouteApp.config(function($routeProvider)
{
     $routeProvider.when('/home',
    {
        templateUrl:'home.html',
        controller:'viewController'
    })
    $routeProvider.when('/viewDetails',
    {
        templateUrl:'viewDetails.html',
        controller:'viewController'
    })
    .otherwise({
        redirectTo:'/home'
    })
});
MyRouteApp.controller('viewController',function($scope){
    $scope.products=[{pname:'Xiaomi',price:20000},{pname:'Samsung',price:40000}];
    $scope.message="click to view product";
})